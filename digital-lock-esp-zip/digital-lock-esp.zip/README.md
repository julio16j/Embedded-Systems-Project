# To run this project you need to do:
###    Download Visual Studio code
###    In Visual Studio code install and configure ESP-IDF extension
###    once did this, go on this repository copy the repository_url and tap on terminal from your pc:
###    "git clone repository_url"
###    this will create the repository folder on pc
###    after that open "digital-lock-esp" folder on Visual Studio code
###    build the project